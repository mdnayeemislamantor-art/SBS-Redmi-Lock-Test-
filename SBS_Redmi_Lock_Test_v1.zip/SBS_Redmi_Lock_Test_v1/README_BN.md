# SBS Redmi Lock Test — Android Project v1

এই প্রজেক্টটি নিজের Android ফোনে **বাস্তব একবারের Screen Lock** পরীক্ষা করার জন্য। এটি EMI Financing Lock, Remote Lock, Unlock bypass, পর্দার ওপর ভুয়া overlay, Device Owner provisioning, বা কোনো লুকানো নিয়ন্ত্রণ নয়।

## ১. আপনার Redmi Note 17-এ কী পরীক্ষা হবে

1. Settings > Passwords & security > Screen lock-এ আপনার জানা PIN/Pattern/Password আগে সেট করুন। **PIN মনে না থাকলে পরীক্ষা করবেন না।**
2. APK তৈরি করে নিজের ফোনে ইনস্টল করুন।
3. `SBS Lock Test` খুলুন। ফোনের নাম, Android version, Lock Permission status দেখতে পাবেন।
4. `১. Lock Permission চালু করুন` চাপুন। Android/HyperOS-এর **Activate this device admin app** অনুমতি-স্ক্রিনে অনুমতি বুঝে Activate করুন।
5. `২. এখনই ফোন লক করুন` চাপুন, নিশ্চিত করুন। সঙ্গে সঙ্গে স্ক্রিন লক হবে।
6. ফোন জাগিয়ে নিজের PIN/Pattern/Password দিয়ে **সত্যিকারের Unlock** করুন। এটি সাধারণ Android system unlock, Admin Panel-এর রিমোট unlock নয়।
7. অ্যাপে ফিরে `Device Admin Permission বন্ধ করুন` চাপুন। চাইলে তারপর অ্যাপ Uninstall করুন।

**গুরুত্বপূর্ণ:** PIN ছাড়া devicePolicyManager.lockNow() স্ক্রিন off করলেও Secure Lock নাও হতে পারে; সে জন্য অ্যাপটি PIN সেট করা না থাকলে Lock বাটন অকার্যকর রাখে। ফোনের PIN, password, biometrics, IMEI, ছবি বা ফাইল অ্যাপটি পড়ে না।

## ২. APK কীভাবে Build করবেন — Android Studio (PC)

- Windows/Mac/Linux PC-তে অফিসিয়াল [Android Studio](https://developer.android.com/studio) ইনস্টল করুন।
- `SBS_Redmi_Lock_Test_v1` প্রজেক্ট ফোল্ডার Open করুন। এই প্রজেক্টে Gradle wrapper JAR নেই: Android Studio Gradle installation নির্বাচন করতে বলতে পারে। `Gradle 8.9`, `JDK 17`, `Android SDK 35` ব্যবহার করুন।
- Gradle plugin 8.7.3, compileSdk 35, minSdk 26, targetSdk 35। External runtime libraries নেই।
- `gradle assembleDebug` চালান (Gradle 8.9 ইনস্টল থাকতে হবে) অথবা Android Studio → Build → Build APK(s)।
- `app/build/outputs/apk/debug/app-debug.apk` তৈরি হবে। সেটি Redmi ফোনে কপি করে ইনস্টল করুন।

## ৩. GitHub Actions-এ ফ্রি APK Build (PC-তে Android Studio ছাড়াও)

এই প্রজেক্টে `.github/workflows/build-debug-apk.yml` রয়েছে।

1. GitHub-এ একটি **private repository** তৈরি করুন।
2. এই ZIP-এর ভিতরের সব ফাইল/ফোল্ডার repository **root**-এ আপলোড করুন (`.github` গোপন ফোল্ডারটি সহ); শুধু ZIP ফাইল আপলোড করলে GitHub নিজে extract করবে না। GitHub-এ upload করার জন্য সাধারণত Git clone/git push বা PC থেকে সঠিক folder structure রাখা সুবিধাজনক।
3. Repository → `Actions` → `Build SBS Lock Test APK` → `Run workflow`। প্রথম push-এ স্বয়ংক্রিয়ভাবেও build শুরু হতে পারে।
4. সফল হলে workflow run-এর `Artifacts` থেকে `SBS-Redmi-Lock-Test-debug-APK` ডাউনলোড করুন। তার ভিতরের `app-debug.apk` ফোনে ইনস্টল করুন।

এটি demo/debug APK; Google Play প্রকাশনার জন্য release signing/security review প্রয়োজন। GitHub Actions-এর free quota আপনার GitHub plan ও usage-এর ওপর নির্ভর করে।

## ৪. EMI Financing Lock: বাস্তব সীমা

- `Lock Now` সাধারণ device-admin screen-lock API; আনলক করার জন্য ফোনের **নিজস্ব** credential আবশ্যক।
- `Financing Lock Feature পরীক্ষা` বাটন `android.software.device_lock` feature পড়ে। **Feature true হওয়া মানেই অ্যাপ অনুমোদিত নয়।** Android-এর financing device lock service পেতে OEM/financing provider অনুমোদন ও kiosk role লাগতে পারে।
- এটি কোনো Admin/Dealer server-এর সঙ্গে সংযুক্ত নয়, ইন্টারনেট permission-ও নেই।
- এই প্রকল্পকে গ্রাহকের ফোনে গোপনে ইনস্টল করবেন না। পরীক্ষা নিজের ফোন বা মালিকের স্পষ্ট সম্মতিতে করুন।

## ৫. Troubleshooting

- Lock button disabled: আগে Screen Lock PIN সেট করুন এবং Device Admin permission Activate করুন।
- Device admin activation refused: Xiaomi HyperOS Settings → Security/Privacy → Device admin apps থেকে দেখুন। নাম ও স্ক্রিনের অবস্থান version অনুযায়ী আলাদা হতে পারে।
- Uninstall আটকে গেলে: `SBS Lock Test` → Device Admin Permission বন্ধ করুন বা Android Settings → Device admin apps থেকে off করে Uninstall করুন।
- Unlock সমস্যায়: আপনার আসল PIN/Pattern/Password লাগবে। অ্যাপ PIN পরিবর্তন করে না, তাই ভুলে গেলে এই অ্যাপ ব্যবহার করে unlock করা যাবে না।
- ফাইল খোলার পর HTML Demo-তে Lock বাটন কাজ করলেও বাস্তব OS lock হবে না; Android APK লাগবে।

## ৬. কোডে নিরাপত্তা যাচাই

- `AndroidManifest.xml`-এ INTERNET, SMS, CAMERA, LOCATION, READ_CONTACTS, ACCESSIBILITY, FACTORY_RESET বা storage permission নেই।
- DeviceAdmin-এর `uses-policies`-এ কেবল `<force-lock />` আছে।
- কোনো background service, boot receiver, alarm, remote command বা user password collection নেই।

## ৭. সূত্র

- https://developer.android.com/reference/android/app/admin/DevicePolicyManager#lockNow()
- https://developer.android.com/reference/android/devicelock/DeviceLockManager
- https://developer.android.com/reference/android/content/pm/PackageManager#FEATURE_DEVICE_LOCK
