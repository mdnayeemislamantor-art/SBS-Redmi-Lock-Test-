package com.sbs.emilocker.locktest;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * SBS LOCAL screen-lock test on the owner's device.
 * It does NOT do remote locking, financed device locking, unlock bypass,
 * persistence, scheduled actions, networking, data collection or factory reset.
 */
public final class MainActivity extends Activity {
    private DevicePolicyManager devicePolicy;
    private ComponentName adminComponent;
    private KeyguardManager keyguard;
    private TextView statusLabel;
    private TextView detailsLabel;
    private Button activateButton;
    private Button lockButton;
    private Button disableButton;

    private static final int BACKGROUND = Color.rgb(13, 23, 43);
    private static final int PANEL = Color.rgb(24, 40, 68);
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(189, 202, 224);
    private static final int BLUE = Color.rgb(48, 112, 239);
    private static final int RED = Color.rgb(194, 54, 78);
    private static final int GREEN = Color.rgb(12, 132, 102);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        devicePolicy = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        adminComponent = new ComponentName(this, SbsAdminReceiver.class);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        if (statusLabel != null) updateStatus();
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private GradientDrawable bg(int color, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }

    private TextView label(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLineSpacing(dp(4), 1f);
        return view;
    }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(18), dp(18), dp(18), dp(18));
        p.setBackground(bg(PANEL, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        return p;
    }

    private void addPanel(LinearLayout root, LinearLayout p) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        root.addView(p, lp);
    }

    private Button addButton(LinearLayout parent, String title, int color, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setBackground(bg(color, 12));
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        parent.addView(b, lp);
        return b;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setFitsSystemWindows(true);
        scroll.setBackgroundColor(BACKGROUND);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(32));
        scroll.addView(root);
        setContentView(scroll);

        root.addView(label("SBS  /  MOBILE LOCKER", 13, true, MUTED));
        TextView header = label("Redmi Lock Test", 27, true, TEXT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(9);
        titleLp.bottomMargin = dp(8);
        root.addView(header, titleLp);
        root.addView(label("আপনার নিজের ফোনে নিরাপদ Screen Lock পরীক্ষা। এটি EMI Remote Lock নয়।", 14, false, MUTED));

        LinearLayout statusPanel = panel();
        statusPanel.addView(label("ডিভাইসের অবস্থা", 16, true, TEXT));
        statusLabel = label("যাচাই হচ্ছে…", 18, true, MUTED);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, -2);
        infoLp.topMargin = dp(12);
        statusPanel.addView(statusLabel, infoLp);
        detailsLabel = label("", 14, false, MUTED);
        statusPanel.addView(detailsLabel, infoLp);
        addPanel(root, statusPanel);

        LinearLayout actionPanel = panel();
        actionPanel.addView(label("Lock / Unlock Test", 17, true, TEXT));
        activateButton = addButton(actionPanel, "১. Lock Permission চালু করুন", BLUE, v -> enableAdmin());
        lockButton = addButton(actionPanel, "২. এখনই ফোন লক করুন", RED, v -> confirmLock());
        addButton(actionPanel, "৩. কীভাবে Unlock করবেন", GREEN, v -> showUnlockHelp());
        addButton(actionPanel, "Screen Lock / PIN সেটিংস", 0xff405574, v -> openSecuritySettings());
        addPanel(root, actionPanel);

        LinearLayout diagnosticsPanel = panel();
        diagnosticsPanel.addView(label("EMI Lock প্রযুক্তি যাচাই", 17, true, TEXT));
        diagnosticsPanel.addView(label("ফোনে Android Financing Device Lock feature আছে কি না পরীক্ষা করুন। Feature থাকলেও SBS-কে OEM অনুমোদন ছাড়া ব্যবহার করতে দেবে না।", 13, false, MUTED));
        addButton(diagnosticsPanel, "Financing Lock Feature পরীক্ষা", BLUE, v -> showFeatureCheck());
        addPanel(root, diagnosticsPanel);

        LinearLayout safetyPanel = panel();
        safetyPanel.addView(label("পরীক্ষা শেষে", 17, true, TEXT));
        disableButton = addButton(safetyPanel, "Device Admin Permission বন্ধ করুন", 0xff637387, v -> confirmDisable());
        safetyPanel.addView(label("এটি কোনো তথ্য সংগ্রহ করে না, ইন্টারনেট ব্যবহার করে না, দূর থেকে নিয়ন্ত্রণ করে না এবং ফোনের PIN পরিবর্তন করে না।", 13, false, MUTED));
        addPanel(root, safetyPanel);
        updateStatus();
    }

    private void updateStatus() {
        boolean adminSupported = getPackageManager().hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN);
        boolean active = devicePolicy != null && devicePolicy.isAdminActive(adminComponent);
        boolean secure = keyguard != null && keyguard.isDeviceSecure();
        String summary = adminSupported ? (active ? "● Lock Permission: ACTIVE" : "● Lock Permission: OFF") : "● Device Admin সমর্থন নেই";
        statusLabel.setText(summary);
        statusLabel.setTextColor(active ? 0xff75e0b3 : 0xffffcd79);
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;
        detailsLabel.setText("ফোন: " + deviceName + "\nAndroid: " + Build.VERSION.RELEASE + "\nPIN/Pattern/Password: " + (secure ? "সেট করা আছে" : "সেট করা নেই"));
        activateButton.setEnabled(adminSupported && !active);
        lockButton.setEnabled(adminSupported && active && secure);
        disableButton.setEnabled(active);
        activateButton.setAlpha(activateButton.isEnabled() ? 1f : .4f);
        lockButton.setAlpha(lockButton.isEnabled() ? 1f : .4f);
        disableButton.setAlpha(disableButton.isEnabled() ? 1f : .4f);
    }

    private void enableAdmin() {
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN)) {
            dialog("সমর্থন নেই", "এই ফোনে Device Administrator feature নেই।");
            return;
        }
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "SBS Lock Test শুধু আপনার বাটন চাপার পরে Screen Lock করতে Device Admin permission চায়। অনুমতি যেকোনো সময় বন্ধ করতে পারবেন।");
        try { startActivity(intent); }
        catch (Exception e) { dialog("সেটিংস খোলা যায়নি", "ফোনের Device Admin সেটিংস থেকে অনুমতি চালু করুন।"); }
    }

    private void confirmLock() {
        if (devicePolicy == null || !devicePolicy.isAdminActive(adminComponent)) {
            dialog("অনুমতি দরকার", "আগে Lock Permission চালু করুন।");
            updateStatus();
            return;
        }
        if (keyguard == null || !keyguard.isDeviceSecure()) {
            dialog("PIN লাগবে", "প্রথমে ফোনে PIN, Pattern বা Password সেট করুন।");
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("ফোনটি এখন লক করবেন?")
            .setMessage("স্ক্রিন সত্যিকারের লক হবে। আগের PIN/Pattern/Password দিয়ে আবার খুলতে পারবেন। নিশ্চিত না হলে Cancel করুন।")
            .setPositiveButton("Lock Now", (d, which) -> {
                try { devicePolicy.lockNow(); }
                catch (SecurityException e) { dialog("Lock ব্যর্থ", "Android বা HyperOS Device Admin Lock অনুমতি দেয়নি। Settings চেক করুন।"); }
                catch (Exception e) { dialog("Lock ব্যর্থ", "এই ডিভাইসে Lock সম্পন্ন হয়নি।"); }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showUnlockHelp() {
        dialog("আসল Unlock পরীক্ষা", "Lock Now চাপলে স্ক্রিন লক হবে। Power বাটন চাপুন বা স্ক্রিন জাগান, তারপর আপনার নিজের PIN/Pattern/Password দিয়ে আনলক করুন।\n\nAndroid সাধারণ third-party অ্যাপকে PIN ছাড়া সিস্টেম Lock Screen আনলক করতে দেয় না। এই অ্যাপ কোনো Unlock bypass করে না।");
    }

    private void showFeatureCheck() {
        boolean hasFeature = Build.VERSION.SDK_INT >= 34 && getPackageManager().hasSystemFeature("android.software.device_lock");
        String result = hasFeature ? "এই ফোন Android Financing Device Lock feature সমর্থন করার দাবি করছে।" : "এই ফোনে Android Financing Device Lock feature রিপোর্ট করা হয়নি।";
        dialog("Financing Device Lock", result + "\n\nএটি শুধু feature detection; OEM/Financing enrollment, role permission এবং API অনুমোদন ছাড়া EMI Lock/Unlock করা যাবে না। এই অ্যাপ সেই অনুমতি দাবি করে না।");
    }

    private void openSecuritySettings() {
        try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
        catch (Exception e) { dialog("সেটিংস", "Settings → Passwords & security → Screen lock থেকে PIN তৈরি করুন।"); }
    }

    private void confirmDisable() {
        new AlertDialog.Builder(this)
            .setTitle("Device Admin Permission বন্ধ করবেন?")
            .setMessage("শুধু এই অ্যাপের Device Admin অনুমতি বন্ধ হবে। আপনার ফোনের PIN/Pattern অপরিবর্তিত থাকবে।")
            .setPositiveButton("বন্ধ করুন", (d, which) -> {
                try {
                    devicePolicy.removeActiveAdmin(adminComponent);
                    updateStatus();
                } catch (Exception e) {
                    dialog("সেটিংস থেকে বন্ধ করুন", "Settings → Security → Device admin apps থেকে SBS Lock Test বন্ধ করুন।");
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void dialog(String title, String msg) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("ঠিক আছে", null).show();
    }
}
