package com.sbs.emilocker.locktest;

import android.app.admin.DeviceAdminReceiver;

/** No background behavior. Only used for user-approved force-lock policy. */
public final class SbsAdminReceiver extends DeviceAdminReceiver { }
