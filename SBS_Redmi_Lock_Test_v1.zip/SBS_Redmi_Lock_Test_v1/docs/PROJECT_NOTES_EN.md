SBS LOCAL SCREEN LOCK TEST v1

Scope: explicit opt-in, local, one-shot Android screen locking on a device the tester owns.
Permissions: only Device Admin force-lock, requested via ACTION_ADD_DEVICE_ADMIN.
Device owner / profile owner: not requested. Financing lock: not implemented.
Unlock: Android system PIN/pattern/password only (no remote unlock or bypass).
Financing capability diagnostics: hasSystemFeature("android.software.device_lock") only, never asserts enrollment or permission.
Build: Android Gradle plugin 8.7.3, Gradle 8.9, JDK 17, SDK 35.
No network, remote commands, sensitive identifiers or user-data collection.
Privacy: all displayed information stays in the foreground UI.
Optional CI: GitHub Actions builds a signed debug APK in repository Actions Artifacts.
This container lacks Android SDK and Gradle so APK compilation has not been verified here.
